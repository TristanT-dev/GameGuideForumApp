## What has been achieved:
- A database (MongoDB) has been created
- Methods to interface with the database have been implemented
- Authentication

## To be accomplished:
- As a user, I want to be able to view a game guide, so that I can be better informed about it
- As a user, I want to be able to create/edit game guides, so that I can add new information to it

## For BTS630:
- As a user, I want to participate in a forum, so that I can discuss games with other gamers
- As a user, I want to use APIs to add information to game guides, so that they are more complete
