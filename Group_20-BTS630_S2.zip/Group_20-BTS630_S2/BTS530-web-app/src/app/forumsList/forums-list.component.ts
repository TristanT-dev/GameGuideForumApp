import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forums-list',
  templateUrl: './forums-list.component.html',
  styleUrls: ['./forums-list.component.css']
})
export class ForumsListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
